# Docker Box

![Docker Box](screenshot.png)

## Installation

Place the widget into the Übersicht widget directory.

## Options

```js
const options = {
  top: "100px",
  left: "420px",
  width: "600px",
};
```
